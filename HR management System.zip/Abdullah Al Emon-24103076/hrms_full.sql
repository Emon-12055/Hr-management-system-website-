
-- ============================================
-- CSE 2397 - DBMS Assignment (Fall 2025)
-- Step 6: SQL Implementation Script
-- Project: Human Resource Management System (HRMS)
-- File: hrms_full.sql
-- ============================================

-- Create Database
CREATE DATABASE hrms_db;
USE hrms_db;

-- ============================================
-- Table: HR_USER
-- ============================================
CREATE TABLE HR_USER (
    h_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    full_name VARCHAR(100) NOT NULL
);

-- ============================================
-- Table: EMPLOYEE
-- ============================================
CREATE TABLE EMPLOYEE (
    e_id INT PRIMARY KEY AUTO_INCREMENT,
    emp_code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    position VARCHAR(50),
    hire_date DATE,
    salary DECIMAL(10,2),
    creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    h_id INT,
    FOREIGN KEY (h_id) REFERENCES HR_USER(h_id)
);

-- ============================================
-- Table: ATTENDANCE
-- ============================================
CREATE TABLE ATTENDANCE (
    a_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    date DATE NOT NULL,
    status VARCHAR(20),
    reason VARCHAR(255),
    record_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    h_id INT,
    FOREIGN KEY (employee_id) REFERENCES EMPLOYEE(e_id),
    FOREIGN KEY (h_id) REFERENCES HR_USER(h_id)
);

-- ============================================
-- Table: PAYMENT
-- ============================================
CREATE TABLE PAYMENT (
    p_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    amount DECIMAL(10,2),
    payment_date DATE,
    method VARCHAR(30),
    remarks VARCHAR(255),
    creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    h_id INT,
    FOREIGN KEY (employee_id) REFERENCES EMPLOYEE(e_id),
    FOREIGN KEY (h_id) REFERENCES HR_USER(h_id)
);

-- ============================================
-- Table: REQUISITION
-- ============================================
CREATE TABLE REQUISITION (
    r_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100),
    description VARCHAR(255),
    creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    h_id INT,
    FOREIGN KEY (h_id) REFERENCES HR_USER(h_id)
);

-- ============================================
-- Table: CANDIDATE
-- ============================================
CREATE TABLE CANDIDATE (
    c_id INT PRIMARY KEY AUTO_INCREMENT,
    requisition_id INT NOT NULL,
    position VARCHAR(50),
    name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    resume_url VARCHAR(255),
    status VARCHAR(30),
    creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (requisition_id) REFERENCES REQUISITION(r_id)
);

-- ============================================
-- Insert Sample Data
-- ============================================

INSERT INTO HR_USER (username, password, full_name) VALUES
('hr_admin', 'admin123', 'HR Administrator'),
('hr_manager', 'manager123', 'HR Manager'),
('hr_exec', 'exec123', 'HR Executive'),
('hr_staff1', 'staff123', 'HR Staff One'),
('hr_staff2', 'staff456', 'HR Staff Two');

INSERT INTO EMPLOYEE (emp_code, name, email, phone, position, hire_date, salary, h_id) VALUES
('EMP001', 'Rahim Uddin', 'rahim@gmail.com', '01710000001', 'Software Engineer', '2022-01-10', 60000, 1),
('EMP002', 'Karim Ahmed', 'karim@gmail.com', '01710000002', 'System Analyst', '2021-05-15', 65000, 1),
('EMP003', 'Nusrat Jahan', 'nusrat@gmail.com', '01710000003', 'HR Officer', '2023-02-01', 45000, 2),
('EMP004', 'Sabbir Hossain', 'sabbir@gmail.com', '01710000004', 'Accountant', '2020-08-20', 55000, 2),
('EMP005', 'Tania Akter', 'tania@gmail.com', '01710000005', 'UI Designer', '2022-11-05', 52000, 3);

INSERT INTO ATTENDANCE (employee_id, date, status, reason, h_id) VALUES
(1, '2025-01-01', 'Present', NULL, 4),
(2, '2025-01-01', 'Present', NULL, 4),
(3, '2025-01-01', 'Absent', 'Sick Leave', 5),
(4, '2025-01-01', 'Present', NULL, 5),
(5, '2025-01-01', 'Late', 'Traffic Issue', 4);

INSERT INTO PAYMENT (employee_id, amount, payment_date, method, remarks, h_id) VALUES
(1, 60000, '2025-01-31', 'Bank Transfer', 'January Salary', 1),
(2, 65000, '2025-01-31', 'Bank Transfer', 'January Salary', 1),
(3, 45000, '2025-01-31', 'Cash', 'January Salary', 2),
(4, 55000, '2025-01-31', 'Bank Transfer', 'January Salary', 2),
(5, 52000, '2025-01-31', 'Bank Transfer', 'January Salary', 3);

INSERT INTO REQUISITION (title, description, h_id) VALUES
('Junior Developer', 'Hiring for junior software developer', 1),
('HR Intern', 'Internship position for HR department', 2),
('Account Executive', 'Account executive required', 2),
('UI/UX Designer', 'Creative designer needed', 3),
('System Engineer', 'System support engineer', 1);

INSERT INTO CANDIDATE (requisition_id, position, name, email, phone, resume_url, status) VALUES
(1, 'Junior Developer', 'Hasan Ali', 'hasan@gmail.com', '01810000001', 'resume1.pdf', 'Shortlisted'),
(1, 'Junior Developer', 'Mizan Rahman', 'mizan@gmail.com', '01810000002', 'resume2.pdf', 'Interviewed'),
(2, 'HR Intern', 'Farzana Islam', 'farzana@gmail.com', '01810000003', 'resume3.pdf', 'Selected'),
(3, 'Account Executive', 'Imran Khan', 'imran@gmail.com', '01810000004', 'resume4.pdf', 'Pending'),
(4, 'UI/UX Designer', 'Sadia Noor', 'sadia@gmail.com', '01810000005', 'resume5.pdf', 'Shortlisted');

-- ============================================
-- End of File
-- ============================================
