-- ============================================
-- CSE 2397 - DBMS Assignment (Fall 2025)
-- Step 7: SQL Query Script (10+ queries)
-- Project: Human Resource Management System (HRMS)
-- File: queries.sql
-- Database: MySQL / MariaDB
-- ============================================

USE hrms_db;

-- ------------------------------------------------
-- Q1) Filtering + Ordering:
-- List all employees ordered by salary (highest first)
-- ------------------------------------------------
SELECT e_id, emp_code, name, position, salary
FROM EMPLOYEE
ORDER BY salary DESC;

-- ------------------------------------------------
-- Q2) Filtering with WHERE:
-- Show employees whose salary is greater than 55000
-- ------------------------------------------------
SELECT e_id, emp_code, name, salary
FROM EMPLOYEE
WHERE salary > 55000
ORDER BY salary DESC;

-- ------------------------------------------------
-- Q3) Pattern match (LIKE):
-- Find employees whose name starts with 'R'
-- ------------------------------------------------
SELECT e_id, emp_code, name, email
FROM EMPLOYEE
WHERE name LIKE 'R%';

-- ------------------------------------------------
-- Q4) JOIN (Employee + Attendance):
-- Show attendance records with employee name
-- ------------------------------------------------
SELECT a.a_id, e.emp_code, e.name, a.date, a.status, a.reason
FROM ATTENDANCE a
JOIN EMPLOYEE e ON e.e_id = a.employee_id
ORDER BY a.date, e.name;

-- ------------------------------------------------
-- Q5) JOIN (Employee + Payment):
-- Show payment history with employee name and method
-- ------------------------------------------------
SELECT p.p_id, e.emp_code, e.name, p.amount, p.payment_date, p.method, p.remarks
FROM PAYMENT p
JOIN EMPLOYEE e ON e.e_id = p.employee_id
ORDER BY p.payment_date DESC, p.amount DESC;

-- ------------------------------------------------
-- Q6) JOIN (Requisition + Candidate):
-- Show candidates under each requisition title
-- ------------------------------------------------
SELECT r.r_id, r.title AS requisition_title, c.c_id, c.name AS candidate_name, c.status
FROM REQUISITION r
JOIN CANDIDATE c ON c.requisition_id = r.r_id
ORDER BY r.r_id, c.c_id;

-- ------------------------------------------------
-- Q7) Aggregate (COUNT):
-- Count total employees by position
-- ------------------------------------------------
SELECT position, COUNT(*) AS total_employees
FROM EMPLOYEE
GROUP BY position
ORDER BY total_employees DESC;

-- ------------------------------------------------
-- Q8) Aggregate (SUM):
-- Calculate total salary expense (monthly base salary total)
-- ------------------------------------------------
SELECT SUM(salary) AS total_salary_expense
FROM EMPLOYEE;

-- ------------------------------------------------
-- Q9) Aggregate with GROUP BY:
-- Total payment amount paid to each employee
-- ------------------------------------------------
SELECT e.emp_code, e.name, SUM(p.amount) AS total_paid
FROM PAYMENT p
JOIN EMPLOYEE e ON e.e_id = p.employee_id
GROUP BY e.emp_code, e.name
ORDER BY total_paid DESC;

-- ------------------------------------------------
-- Q10) Aggregate with HAVING:
-- Show employees who received total payment >= 55000
-- ------------------------------------------------
SELECT e.emp_code, e.name, SUM(p.amount) AS total_paid
FROM PAYMENT p
JOIN EMPLOYEE e ON e.e_id = p.employee_id
GROUP BY e.emp_code, e.name
HAVING SUM(p.amount) >= 55000
ORDER BY total_paid DESC;

-- ------------------------------------------------
-- Q11) Subquery:
-- Find employee(s) who have the maximum salary
-- ------------------------------------------------
SELECT e_id, emp_code, name, salary
FROM EMPLOYEE
WHERE salary = (SELECT MAX(salary) FROM EMPLOYEE);

-- ------------------------------------------------
-- Q12) INSERT (New employee):
-- Add a new employee record
-- ------------------------------------------------
INSERT INTO EMPLOYEE (emp_code, name, email, phone, position, hire_date, salary, h_id)
VALUES ('EMP006', 'Shakib Hasan', 'shakib@gmail.com', '01710000006', 'Support Engineer', '2024-03-01', 48000, 3);

-- Verify insert
SELECT e_id, emp_code, name, email, position, salary
FROM EMPLOYEE
WHERE emp_code = 'EMP006';

-- ------------------------------------------------
-- Q13) UPDATE:
-- Update salary of EMP006 (increment by 2000)
-- ------------------------------------------------
UPDATE EMPLOYEE
SET salary = salary + 2000
WHERE emp_code = 'EMP006';

-- Verify update
SELECT e_id, emp_code, name, salary
FROM EMPLOYEE
WHERE emp_code = 'EMP006';

-- ------------------------------------------------
-- Q14) DELETE:
-- Delete EMP006 (note: make sure no attendance/payment references exist)
-- ------------------------------------------------
DELETE FROM EMPLOYEE
WHERE emp_code = 'EMP006';

-- Verify delete
SELECT e_id, emp_code, name
FROM EMPLOYEE
WHERE emp_code = 'EMP006';

-- ------------------------------------------------
-- Q15) Multi-join (HR_USER + EMPLOYEE):
-- Show who created/added each employee
-- ------------------------------------------------
SELECT e.emp_code, e.name AS employee_name, u.full_name AS created_by
FROM EMPLOYEE e
LEFT JOIN HR_USER u ON u.h_id = e.h_id
ORDER BY e.emp_code;

-- ------------------------------------------------
-- Q16) Attendance summary (Aggregate + Filter):
-- Count attendance status records (Present/Absent/Late)
-- ------------------------------------------------
SELECT status, COUNT(*) AS total_records
FROM ATTENDANCE
GROUP BY status
ORDER BY total_records DESC;

-- ============================================
-- End of queries.sql
-- ============================================
