-- ============================================
-- CSE 2397 - DBMS Assignment (Fall 2025)
-- Step 8: Transaction Management Demo
-- Project: Human Resource Management System (HRMS)
-- File: transactions.sql
-- Database: MySQL / MariaDB
-- ============================================

USE hrms_db;

-- ============================================
-- SCENARIO:
-- Salary payment for an employee must be treated
-- as a single atomic transaction.
-- ============================================

-- ------------------------------------------------
-- Transaction 1: Successful salary payment (COMMIT)
-- ------------------------------------------------
START TRANSACTION;

-- Insert salary payment record
INSERT INTO PAYMENT (employee_id, amount, payment_date, method, remarks, h_id)
VALUES (1, 60000, '2025-02-28', 'Bank Transfer', 'February Salary', 1);

-- If everything is correct, commit the transaction
COMMIT;

-- Verify payment record
SELECT * FROM PAYMENT WHERE remarks = 'February Salary';

-- ------------------------------------------------
-- Transaction 2: Using SAVEPOINT and ROLLBACK
-- ------------------------------------------------
START TRANSACTION;

-- Insert salary payment for another employee
INSERT INTO PAYMENT (employee_id, amount, payment_date, method, remarks, h_id)
VALUES (2, 65000, '2025-02-28', 'Bank Transfer', 'February Salary', 1);

-- Create a savepoint after successful insert
SAVEPOINT after_payment_insert;

-- Attempt to insert an invalid attendance record
-- (This simulates an error scenario)
INSERT INTO ATTENDANCE (employee_id, date, status, reason, h_id)
VALUES (999, '2025-02-28', 'Present', NULL, 1);

-- Rollback to savepoint due to error
ROLLBACK TO after_payment_insert;

-- Commit the valid part of the transaction
COMMIT;

-- Verify that payment exists but invalid attendance does not
SELECT * FROM PAYMENT WHERE remarks = 'February Salary';
SELECT * FROM ATTENDANCE WHERE employee_id = 999;

-- ------------------------------------------------
-- Transaction 3: Full rollback scenario
-- ------------------------------------------------
START TRANSACTION;

-- Insert payment
INSERT INTO PAYMENT (employee_id, amount, payment_date, method, remarks, h_id)
VALUES (3, 45000, '2025-02-28', 'Cash', 'February Salary', 2);

-- Something goes wrong, rollback entire transaction
ROLLBACK;

-- Verify rollback
SELECT * FROM PAYMENT WHERE employee_id = 3 AND remarks = 'February Salary';

-- ============================================
-- End of transactions.sql
-- ============================================
